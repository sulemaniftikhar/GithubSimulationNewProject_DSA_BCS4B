#ifndef GITHEADER_H
#define GITHEADER_H

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <map>
#include <unordered_map>
#include <sstream>

using namespace std;

// Forward declarations
class Repository;
class User;
class Commit;
class File;

class User
{
private:
    string username;
    string password;
    vector<string> followers;

    unordered_map<string, vector<string> > unmap;

    // Function to validate if a username exists in the user database
    bool userExists(string &username)
    {
        if (auto it = unmap.find(username) != unmap.end())
            return true;
        return false;
    }

public:
    User()
        : username(""), password("") {}

    User(const string &username, const string &password)
        : username(username), password(password) {}

    // Function to get the password of the user
    string getPassword()
    {
        return password;
    }

    // Function to get the username of the user
    string getUsername()
    {
        return username;
    }

    void setCurrentUser(string username)
    {
        ofstream current("currentUser.csv");
        current << username;
        current.close();
    }

    bool follow(string &currUser, string &userToFollow)
    {
        if (unmap.empty())
        {
            cout << "No user exist!" << endl;
            return false;
        }
        if (userExists(userToFollow))
        {
            unmap[userToFollow].push_back(currUser);
            return true;
        }
        return false;
    }

    // Function to load user followers data into the hash table
    vector<string> loadFollowers(string userName)
    {
        vector<string> f;
        ifstream file("followers.csv");
        if (!file.is_open())
        {
            cout << "file not opened" << endl;
        }
        string line;

        while (getline(file, line))
        {
            stringstream ss(line);
            string user, follower;
            getline(ss, user, ',');
            if (userName == user)
            {
                while (getline(ss, follower, ','))
                {
                    f.push_back(follower);
                }
                return f;
            }
        }

        cout << "User doesn't exists!" << endl;
        file.close();
        return f;
    }

    void saveData()
    {
        ofstream file("followers.csv");

        for (auto it = unmap.begin(); it != unmap.end(); it++)
        {
            file << it->first << ",";
            for (auto follower : it->second)
            {
                file << follower << ",";
            }
            file << endl;
        }

        file.close();
    }

    // Function to load user data into the hash table
    void loadUsersData()
    {
        ifstream file("users.csv");
        if (!file.is_open())
        {
            cout << "Error: Unable to open users.csv" << endl;
            return;
        }

        string line;
        while (getline(file, line))
        {
            stringstream ss(line);
            string user;
            getline(ss, user, ',');
            cout << user << endl;
            cout << 1 << endl;
            vector<string> followersVector = loadFollowers(user);
            cout << 2 << endl;

            for (auto users : followersVector)
            {
                cout << users << " , ";
            }
            cout << 3 << endl;

            // problem appering here;
            
            // auto pair = std::make_pair(user, f);
            // unmap.insert(pair);

            unmap[user] = followersVector;
        }
        file.close();

        cout << "Loaded Data:" << endl;
        for (auto &pair : unmap)
        {
            cout << "User: " << pair.first << endl
                 << " Followers: " << endl;
            for (auto &follower : pair.second)
            {
                cout << follower << " , ";
            }
            cout << endl;
        }
    }
};

class UserRepository
{
private:
    unordered_map<string, User *> users; // Hash table to store users
public:
    UserRepository();
    ~UserRepository();

    User *registerUser(const string &username, const string &password);
    User *loginUser(const string &username, const string &password);
    void logoutUser(User *user);
    User *getUserByUsername(const string &username);
    void LoadData();
    void SaveData();
    void ProfileView(const string &username);
};
class Branch
{
public:
    string Filename;
    string FileData;
    int branchID;
    Branch *next;
    Branch(string Filename, string FileData)
        : Filename(Filename), FileData(FileData), next(nullptr){};

    Branch() {}
};

class Repo : public User
{
public:
    int id;
    string RepoName;
    string ownerName;
    bool isPublic;
    Repo *Contributors;
    Repo *next;
    Repo *commits;
    Repo *commitNext;
    int commitCount;
    string ReadmeFile;
    int ForkCount;
    string ForkOwner;

    Repo(string RepoName, bool isPublic)
    {
        srand(time(0));
        this->id = rand() % 100 + 1;
        this->RepoName = RepoName;
        this->isPublic = isPublic;
        this->commitNext = nullptr;
        this->commits = nullptr;
        this->commitCount = 0;
        this->ForkCount = 0;
        this->ForkOwner = "";
        this->ownerName = getUsername();
    }

    Repo() {}

    // Methods for Repo
    void CreateRepo(string RepoName, bool isPublic)
    {
        Repo(RepoName, isPublic);
    }
    void AddFileToBranch()
    {
    }
    void AddBranch()
    {
    }
    void DeleteFileToBrnach(int id)
    {
    }
    void deleteBranch()
    {
    }
    void Commit(string RepoNAme)
    {
    }
    void Fork(string RepoName)
    {
    }
};
class FileNode
{
public:
    string Filename;
    FileNode *next;
    FileNode(string Filename) : Filename(Filename), next(nullptr){};
};
class FileLinkedlist
{
    FileNode *head;
    FileLinkedlist() : head(nullptr){};

    void insertAtLast(string data)
    {

        FileNode *newNode = new FileNode(data);
        if (head == nullptr)
        {
            head = newNode;
        }
        else
        {
            FileNode *temp = head;
            while (temp->next != nullptr)
            {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    void deleteFile(string name)
    {
        if (head == nullptr)
        {
            cout << "List is empty. Cannot delete." << endl;
            return;
        }

        FileNode *temp = head;
        FileNode *prev = nullptr;

        // If head node itself holds the key to be deleted
        if (temp != nullptr && temp->Filename == name)
        {
            head = temp->next;
            delete temp;
            cout << "File with name " << name << " deleted successfully." << endl;
            return;
        }

        // Search for the key to be deleted, keep track of the
        // previous node as we need to change 'prev->next'
        while (temp != nullptr && temp->Filename != name)
        {
            prev = temp;
            temp = temp->next;
        }

        // If key was not present in linked list
        if (temp == nullptr)
        {
            cout << "File with ID " << name << " not found in the list." << endl;
            return;
        }

        // Unlink the node from linked list
        prev->next = temp->next;
        delete temp;
        cout << "File with ID " << name << " deleted successfully." << endl;
    }

    void printFiles()
    {
        if (head == nullptr)
        {
            cout << "No files in the list." << endl;
            return;
        }

        FileNode *temp = head;
        cout << "Files in the list:" << endl;
        while (temp != nullptr)
        {
            cout << "File name: " << temp->Filename << ", File Name: " << temp->Filename << endl;
            temp = temp->next;
        }
    }
};

class CompleteRepoNode
{
public:
    Repo data;
    CompleteRepoNode *right;
    CompleteRepoNode *left;
    CompleteRepoNode(Repo data)
        : data(data), right(nullptr), left(nullptr){};
    int GetRootId()
    {
        return data.id;
    }
};

class BranchIngRepoTree
{
private:
    CompleteRepoNode *root;
    Branch *branch;

    CompleteRepoNode *insertMainBranch(CompleteRepoNode *root, Repo data)
    {
        // If the tree is empty, create a new node as root
        if (root == nullptr)
            return new CompleteRepoNode(data);

        // Otherwise, recur down the tree
        if (data.id < root->data.id)
            root->left = insertMainBranch(root->left, data);
        else if (data.id > root->data.id)
            root->right = insertMainBranch(root->right, data);

        // Return the unchanged node pointer
        return root;
    }

    CompleteRepoNode *insertSubbranches(CompleteRepoNode *root, Branch data)
    {

        // Otherwise, recur down the tree
        if (data.branchID < root->data.id)
            root->left = insertSubbranches(root->left, data);
        else if (data.branchID > root->data.id)
            root->right = insertSubbranches(root->right, data);

        // Return the unchanged node pointer
        return root;
    }

    CompleteRepoNode *searchByID(CompleteRepoNode *root, int id)
    {
        // Base cases: root is null or key is present at root
        if (root == nullptr || root->data.id == id)
            return root;

        // Key is greater than root's key
        if (root->data.id < id)
            return searchByID(root->right, id);

        // Key is smaller than root's key
        return searchByID(root->left, id);
    }

    void inorderTraversal(CompleteRepoNode *root)
    {
        if (root != nullptr)
        {
            inorderTraversal(root->left);
            cout << "ID: " << root->data.id << ", Repo Name: " << root->data.RepoName << endl;
            inorderTraversal(root->right);
        }
    }

public:
    BranchIngRepoTree()
        : root(nullptr) {}
    void insertRepo(Repo data, Branch sub)
    {
        if (root == nullptr)
        {
            root = insertMainBranch(root, data);
        }
        else
        {
            if (sub.branchID < root->GetRootId())
            {
                root->left = insertSubbranches(root, sub);
            }
            else if (sub.branchID > root->GetRootId())
            {
                root->right = insertSubbranches(root, sub);
            }
        }
    }
};

#endif